import os
import os.path as osp
from typing import List, Optional, Sequence

import torch
from mmengine.dataset import BaseDataset
from mmseg.registry import DATASETS


def _default_palette(num_classes: int = 19):
    # Stable, simple palette. Replace with your official PASTIS palette if needed.
    palette = []
    for i in range(num_classes):
        palette.append([
            int((37 * i + 17) % 256),
            int((67 * i + 29) % 256),
            int((97 * i + 43) % 256),
        ])
    return palette


@DATASETS.register_module()
class PASTISPtDataset(BaseDataset):
    """PASTIS preprocessed `.pt` dataset.

    Expected directory:

    data_root/
    ├── pastis_r_train/
    │   ├── s2_images/{idx}.pt      # [T, C, H, W], default [12, 13, 128, 128]
    │   └── targets.pt              # [N, H, W], labels 0-18, ignore -1
    ├── pastis_r_val/
    └── pastis_r_test/

    Each image file name stem is used as the target index:
    `s2_images/17.pt` -> `targets[17]`.
    """

    METAINFO = dict(
        classes=tuple(f'class_{i:02d}' for i in range(19)),
        palette=_default_palette(19),
        label_map=None,
        reduce_zero_label=False,
    )

    def __init__(
        self,
        data_root: str,
        split: str,
        pipeline: Optional[Sequence] = None,
        metainfo: Optional[dict] = None,
        test_mode: bool = False,
        lazy_init: bool = False,
        serialize_data: bool = True,
        expected_time_steps: int = 12,
        expected_channels: int = 13,
        expected_size: int = 128,
        **kwargs,
    ) -> None:
        self.split = split
        self.expected_time_steps = expected_time_steps
        self.expected_channels = expected_channels
        self.expected_size = expected_size

        self.split_dir = osp.join(data_root, split)
        self.img_dir = osp.join(self.split_dir, 's2_images')
        self.targets_path = osp.join(self.split_dir, 'targets.pt')

        if pipeline is None:
            pipeline = []

        super().__init__(
            ann_file='',
            metainfo=metainfo,
            data_root=data_root,
            data_prefix=dict(),
            filter_cfg=None,
            indices=None,
            serialize_data=serialize_data,
            pipeline=pipeline,
            test_mode=test_mode,
            lazy_init=lazy_init,
            **kwargs,
        )

    @staticmethod
    def _numeric_stem(path: str) -> int:
        stem = osp.splitext(osp.basename(path))[0]
        try:
            return int(stem)
        except ValueError as exc:
            raise ValueError(
                f'Image file name must be a numeric stem like "0.pt", got: {path}'
            ) from exc

    def load_data_list(self) -> List[dict]:
        if not osp.isdir(self.img_dir):
            raise FileNotFoundError(f's2_images directory not found: {self.img_dir}')
        if not osp.isfile(self.targets_path):
            raise FileNotFoundError(f'targets.pt not found: {self.targets_path}')

        image_files = [
            osp.join(self.img_dir, name) for name in os.listdir(self.img_dir)
            if name.endswith('.pt')
        ]
        image_files = sorted(image_files, key=self._numeric_stem)

        if len(image_files) == 0:
            raise RuntimeError(f'No .pt image files found in: {self.img_dir}')

        # Only load metadata shape once for consistency checks.
        targets = torch.load(self.targets_path, map_location='cpu')
        if not torch.is_tensor(targets):
            raise TypeError(
                f'targets.pt must contain a Tensor, but got {type(targets)}')
        if targets.ndim != 3:
            raise ValueError(
                f'targets.pt must have shape [N, H, W], got {tuple(targets.shape)}')

        max_index = max(self._numeric_stem(p) for p in image_files)
        if max_index >= int(targets.shape[0]):
            raise IndexError(
                f'Max image index {max_index} exceeds targets length {targets.shape[0]}.')

        data_list = []
        for img_path in image_files:
            target_index = self._numeric_stem(img_path)
            data_list.append(
                dict(
                    img_path=img_path,
                    gt_path=self.targets_path,
                    target_index=target_index,
                    seg_map_path=self.targets_path,
                    img_id=target_index,
                    reduce_zero_label=False,
                    expected_time_steps=self.expected_time_steps,
                    expected_channels=self.expected_channels,
                    expected_size=self.expected_size,
                ))

        return data_list
