from mmengine.hooks import Hook
from mmengine.registry import HOOKS


@HOOKS.register_module()
class FreezeBackboneByEpochHook(Hook):
    """Freeze backbone or spatial encoder for the first N epochs.

    Args:
        freeze_epochs: epochs to freeze from epoch 0.
        target:
            - "spatial_encoder": freeze only HuggingFace SwinV2 encoder.
              Temporal fusion and decode head keep training.
            - "backbone": freeze the whole custom backbone.
        verbose: log freeze/unfreeze messages.
    """

    priority = 'VERY_HIGH'

    def __init__(
        self,
        freeze_epochs: int,
        target: str = 'spatial_encoder',
        verbose: bool = True,
    ) -> None:
        if target not in ('spatial_encoder', 'backbone'):
            raise ValueError('target must be "spatial_encoder" or "backbone".')
        self.freeze_epochs = int(freeze_epochs)
        self.target = target
        self.verbose = verbose
        self._is_frozen = None

    @staticmethod
    def _unwrap_model(model):
        return model.module if hasattr(model, 'module') else model

    def _set_trainable(self, runner, trainable: bool):
        model = self._unwrap_model(runner.model)
        backbone = model.backbone

        if self.target == 'spatial_encoder':
            if hasattr(backbone, 'set_spatial_encoder_trainable'):
                backbone.set_spatial_encoder_trainable(trainable)
            elif hasattr(backbone, 'set_spatial_trainable'):
                backbone.set_spatial_trainable(trainable)
            else:
                raise AttributeError(
                    'backbone does not implement set_spatial_encoder_trainable() '
                    'or set_spatial_trainable().'
                )
        else:
            for param in backbone.parameters():
                param.requires_grad = trainable
            if trainable:
                backbone.train()
            else:
                backbone.eval()

        self._is_frozen = not trainable
        if self.verbose:
            action = 'Unfroze' if trainable else 'Froze'
            runner.logger.info(
                f'{action} {self.target} at epoch={runner.epoch}. '
                f'freeze_epochs={self.freeze_epochs}'
            )

    def before_train(self, runner) -> None:
        if self.freeze_epochs > 0:
            self._set_trainable(runner, trainable=False)

    def before_train_epoch(self, runner) -> None:
        if self.freeze_epochs <= 0:
            return

        if runner.epoch < self.freeze_epochs:
            if self._is_frozen is not True:
                self._set_trainable(runner, trainable=False)
        else:
            if self._is_frozen is not False:
                self._set_trainable(runner, trainable=True)
