# pastis_mmseg/engine/hooks/freeze_backbone_hook.py

from mmengine.hooks import Hook
from mmengine.registry import HOOKS


@HOOKS.register_module()
class FreezeBackboneByEpochHook(Hook):
    """Freeze backbone or spatial encoder for the first N epochs.

    Args:
        freeze_epochs: epochs to freeze from epoch 0.
        target:
            - "spatial_encoder": freeze only HuggingFace SwinV2 spatial encoder.
              Temporal fusion and decode head keep training.
            - "backbone": freeze the whole custom backbone.
        verbose: log freeze/unfreeze messages.

    Compatibility:
        The hook supports both backbone APIs:
            set_spatial_trainable(trainable)
            set_spatial_encoder_trainable(trainable)

        This fixes errors like:
            backbone does not implement set_spatial_trainable()
            backbone does not implement set_spatial_encoder_trainable()
    """

    priority = 'VERY_HIGH'

    def __init__(
        self,
        freeze_epochs: int,
        target: str = 'spatial_encoder',
        verbose: bool = True,
    ) -> None:
        if target not in ('spatial_encoder', 'backbone'):
            raise ValueError('target must be "spatial_encoder" or "backbone".')
        self.freeze_epochs = int(freeze_epochs)
        self.target = target
        self.verbose = verbose
        self._is_frozen = None

    @staticmethod
    def _unwrap_model(model):
        return model.module if hasattr(model, 'module') else model

    @staticmethod
    def _unwrap_module(module):
        return module.module if hasattr(module, 'module') else module

    def _get_backbone(self, runner):
        model = self._unwrap_model(runner.model)

        if not hasattr(model, 'backbone'):
            raise AttributeError(
                f'The wrapped model {type(model).__name__} has no `backbone`.'
            )

        return self._unwrap_module(model.backbone)

    def _set_spatial_encoder_trainable(self, backbone, trainable: bool) -> str:
        """Set spatial encoder trainability and return the method used."""
        candidate_methods = (
            'set_spatial_trainable',
            'set_spatial_encoder_trainable',
        )

        for method_name in candidate_methods:
            if hasattr(backbone, method_name):
                getattr(backbone, method_name)(trainable)
                return method_name

        # Fallback: if the custom backbone exposes the HuggingFace SwinV2 module
        # as `swinv2`, freeze/unfreeze that module directly.
        if hasattr(backbone, 'swinv2'):
            spatial_encoder = backbone.swinv2

            for param in spatial_encoder.parameters():
                param.requires_grad = trainable

            if trainable:
                spatial_encoder.train()
                if hasattr(backbone, '_spatial_frozen'):
                    backbone._spatial_frozen = False
            else:
                spatial_encoder.eval()
                if hasattr(backbone, '_spatial_frozen'):
                    backbone._spatial_frozen = True

            return 'fallback_swinv2_parameters'

        raise AttributeError(
            f'backbone {type(backbone).__name__} does not implement any of '
            f'{candidate_methods}, and it has no `.swinv2` module for fallback.'
        )

    def _set_trainable(self, runner, trainable: bool):
        backbone = self._get_backbone(runner)

        if self.target == 'spatial_encoder':
            method_used = self._set_spatial_encoder_trainable(
                backbone=backbone,
                trainable=trainable,
            )
        else:
            for param in backbone.parameters():
                param.requires_grad = trainable
            if trainable:
                backbone.train()
            else:
                backbone.eval()
            method_used = 'backbone.parameters'

        self._is_frozen = not trainable

        if self.verbose:
            action = 'Unfroze' if trainable else 'Froze'
            runner.logger.info(
                f'{action} {self.target} at epoch={runner.epoch}. '
                f'freeze_epochs={self.freeze_epochs}. '
                f'method={method_used}'
            )

    def before_train(self, runner) -> None:
        if self.freeze_epochs > 0:
            self._set_trainable(runner, trainable=False)

    def before_train_epoch(self, runner) -> None:
        if self.freeze_epochs <= 0:
            return

        if runner.epoch < self.freeze_epochs:
            if self._is_frozen is not True:
                self._set_trainable(runner, trainable=False)
        else:
            if self._is_frozen is not False:
                self._set_trainable(runner, trainable=True)
