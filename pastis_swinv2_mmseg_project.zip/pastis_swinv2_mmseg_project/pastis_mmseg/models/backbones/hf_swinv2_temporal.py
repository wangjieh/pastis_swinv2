# pastis_mmseg/models/backbones/hf_swinv2_temporal.py

from typing import List, Optional, Sequence, Tuple
import math

import torch
import torch.nn as nn
from mmengine.model import BaseModule
from mmseg.registry import MODELS

try:
    from transformers import Swinv2Config, Swinv2Model
except ImportError as exc:
    raise ImportError(
        'This project requires HuggingFace transformers. '
        'Please install it with: pip install transformers'
    ) from exc


class TemporalMeanFusion(nn.Module):
    """Mean pooling over temporal dimension.

    Input:
        x: [B, T, C, H, W]

    Output:
        out: [B, C, H, W]
    """

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim != 5:
            raise ValueError(
                f'TemporalMeanFusion expects [B, T, C, H, W], '
                f'but got {tuple(x.shape)}'
            )
        return x.mean(dim=1)


class TemporalMaxFusion(nn.Module):
    """Max pooling over temporal dimension.

    Input:
        x: [B, T, C, H, W]

    Output:
        out: [B, C, H, W]
    """

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim != 5:
            raise ValueError(
                f'TemporalMaxFusion expects [B, T, C, H, W], '
                f'but got {tuple(x.shape)}'
            )
        return x.max(dim=1).values


class TemporalAttentionFusion(nn.Module):
    """Temporal attention fusion for one SwinV2 stage.

    Important:
        This module is stage-specific. ``dim`` must match the real channel
        number of the current SwinV2 stage.

    Typical stage channels:
        SwinV2-Tiny / Small: [96, 192, 384, 768]
        SwinV2-Base:         [128, 256, 512, 1024]
        SwinV2-Large:        [192, 384, 768, 1536]
    """

    def __init__(
        self,
        dim: int,
        reduction: int = 4,
        min_hidden_dim: int = 16,
    ) -> None:
        super().__init__()

        hidden_dim = max(dim // reduction, min_hidden_dim)

        self.norm = nn.LayerNorm(dim)
        self.attn = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward.

        Args:
            x: Tensor with shape [B, T, C, H, W].

        Returns:
            Tensor with shape [B, C, H, W].
        """
        if x.ndim != 5:
            raise ValueError(
                f'TemporalAttentionFusion expects a 5D tensor '
                f'[B, T, C, H, W], but got shape {tuple(x.shape)}'
            )

        b, t, c, h, w = x.shape

        pooled = x.mean(dim=(-2, -1))       # [B, T, C]
        pooled = self.norm(pooled)          # [B, T, C]

        weight = self.attn(pooled)          # [B, T, 1]
        weight = torch.softmax(weight, dim=1)
        weight = weight.view(b, t, 1, 1, 1)

        out = (x * weight).sum(dim=1)       # [B, C, H, W]
        return out


def _make_temporal_fusion(
    fusion_type: str,
    dim: int,
    reduction: int = 4,
) -> nn.Module:
    fusion_type = fusion_type.lower()

    if fusion_type in ('attention', 'attn', 'temporal_attention'):
        return TemporalAttentionFusion(dim=dim, reduction=reduction)

    if fusion_type in ('mean', 'avg', 'average'):
        return TemporalMeanFusion()

    if fusion_type in ('max', 'maximum'):
        return TemporalMaxFusion()

    raise ValueError(
        f'Unsupported temporal_fusion={fusion_type}. '
        f'Available options: attention, mean, max.'
    )


@MODELS.register_module()
class HFSwinV2TemporalBackbone(BaseModule):
    """HuggingFace SwinV2 spatial encoder + multi-scale temporal fusion.

    Expected input:
        [B, T, C, H, W]

    For your PASTIS setting:
        [B, 12, 13, 128, 128]

    Output:
        A tuple of multi-scale features for MMSeg decode heads.

    Example for SwinV2-Base:
        (
            [B, 128, H/4,  W/4],
            [B, 256, H/8,  W/8],
            [B, 512, H/16, W/16],
            [B, 1024, H/32, W/32],
        )

    Freeze API:
        set_spatial_trainable(trainable)
        set_spatial_encoder_trainable(trainable)

    Both names are intentionally supported because different hooks/configs may
    call different method names.
    """

    size_to_default_cfg = {
        'tiny': dict(
            embed_dim=96,
            depths=[2, 2, 6, 2],
            num_heads=[3, 6, 12, 24],
        ),
        'small': dict(
            embed_dim=96,
            depths=[2, 2, 18, 2],
            num_heads=[3, 6, 12, 24],
        ),
        'base': dict(
            embed_dim=128,
            depths=[2, 2, 18, 2],
            num_heads=[4, 8, 16, 32],
        ),
        'large': dict(
            embed_dim=192,
            depths=[2, 2, 18, 2],
            num_heads=[6, 12, 24, 48],
        ),
    }

    def __init__(
        self,
        hf_model_name_or_path: Optional[str] = None,
        swinv2_size: str = 'base',
        pretrained: bool = True,
        in_channels: int = 13,
        num_channels: Optional[int] = None,
        image_size: int = 128,
        patch_size: int = 4,
        window_size: int = 8,
        out_indices: Sequence[int] = (0, 1, 2, 3),
        temporal_fusion: str = 'attention',
        temporal_reduction: int = 4,
        output_hidden_states: bool = True,
        gradient_checkpointing: bool = False,
        norm_eval: bool = False,
        ignore_mismatched_sizes: bool = True,
        expected_embed_dim: Optional[int] = None,
        init_cfg: Optional[dict] = None,
        **kwargs,
    ) -> None:
        super().__init__(init_cfg=init_cfg)

        if num_channels is not None:
            in_channels = num_channels

        self.hf_model_name_or_path = hf_model_name_or_path
        self.swinv2_size = swinv2_size.lower()
        self.pretrained = pretrained
        self.in_channels = int(in_channels)
        self.image_size = image_size
        self.patch_size = patch_size
        self.window_size = window_size
        self.out_indices = tuple(out_indices)
        self.temporal_fusion = temporal_fusion
        self.temporal_reduction = temporal_reduction
        self.output_hidden_states = output_hidden_states
        self.gradient_checkpointing = gradient_checkpointing
        self.norm_eval = norm_eval
        self.ignore_mismatched_sizes = ignore_mismatched_sizes
        self.expected_embed_dim = expected_embed_dim

        self._spatial_frozen = False

        self.config = self._build_config(
            hf_model_name_or_path=hf_model_name_or_path,
            swinv2_size=self.swinv2_size,
            in_channels=self.in_channels,
            image_size=image_size,
            patch_size=patch_size,
            window_size=window_size,
        )

        self.swinv2 = self._build_swinv2_model(
            config=self.config,
            hf_model_name_or_path=hf_model_name_or_path,
            pretrained=pretrained,
            ignore_mismatched_sizes=ignore_mismatched_sizes,
        )

        if self.gradient_checkpointing:
            if hasattr(self.swinv2, 'gradient_checkpointing_enable'):
                self.swinv2.gradient_checkpointing_enable()
            else:
                raise RuntimeError(
                    'The current transformers Swinv2Model does not support '
                    'gradient_checkpointing_enable().'
                )

        self.all_stage_channels = self._infer_all_stage_channels(self.config)

        if max(self.out_indices) >= len(self.all_stage_channels):
            raise ValueError(
                f'out_indices={self.out_indices} is invalid for stage channels '
                f'{self.all_stage_channels}.'
            )

        self.stage_channels = [
            self.all_stage_channels[i] for i in self.out_indices
        ]

        if expected_embed_dim is not None:
            inferred_embed_dim = self.all_stage_channels[0]
            if int(expected_embed_dim) != int(inferred_embed_dim):
                raise ValueError(
                    f'expected_embed_dim={expected_embed_dim}, but the loaded '
                    f'HuggingFace config implies embed_dim={inferred_embed_dim}. '
                    f'Please check SWINV2_SIZE / SWINV2_EMBED_DIMS / SWINV2_PATH.'
                )

        self.temporal_fusions = nn.ModuleList([
            _make_temporal_fusion(
                fusion_type=temporal_fusion,
                dim=channels,
                reduction=temporal_reduction,
            )
            for channels in self.stage_channels
        ])

        self.out_channels = self.stage_channels

    def _build_config(
        self,
        hf_model_name_or_path: Optional[str],
        swinv2_size: str,
        in_channels: int,
        image_size: int,
        patch_size: int,
        window_size: int,
    ) -> Swinv2Config:
        """Build HuggingFace SwinV2 config.

        If ``hf_model_name_or_path`` points to a local HuggingFace directory,
        this method loads its config.json. Otherwise it creates a config from
        the built-in size presets.
        """
        if hf_model_name_or_path:
            config = Swinv2Config.from_pretrained(hf_model_name_or_path)
        else:
            if swinv2_size not in self.size_to_default_cfg:
                raise ValueError(
                    f'Unsupported swinv2_size={swinv2_size}. '
                    f'Available: {list(self.size_to_default_cfg.keys())}'
                )

            default_cfg = self.size_to_default_cfg[swinv2_size]
            config = Swinv2Config(
                image_size=image_size,
                patch_size=patch_size,
                num_channels=in_channels,
                embed_dim=default_cfg['embed_dim'],
                depths=default_cfg['depths'],
                num_heads=default_cfg['num_heads'],
                window_size=window_size,
            )

        # Force these values to match your PASTIS data.
        config.num_channels = in_channels
        config.image_size = image_size
        config.patch_size = patch_size

        if hasattr(config, 'window_size'):
            config.window_size = window_size

        # Make sure hidden states are returned.
        config.output_hidden_states = True
        config.return_dict = True

        return config

    def _build_swinv2_model(
        self,
        config: Swinv2Config,
        hf_model_name_or_path: Optional[str],
        pretrained: bool,
        ignore_mismatched_sizes: bool,
    ) -> Swinv2Model:
        """Build SwinV2 model.

        When pretrained=True:
            Load HuggingFace local weights. If the original checkpoint is
            3-channel while the current config is 13-channel, the patch
            embedding mismatch can be ignored and re-initialized.

        When pretrained=False:
            Build from config and train from scratch.
        """
        if pretrained:
            if not hf_model_name_or_path:
                raise ValueError(
                    'pretrained=True requires hf_model_name_or_path to be set.'
                )

            model = Swinv2Model.from_pretrained(
                hf_model_name_or_path,
                config=config,
                ignore_mismatched_sizes=ignore_mismatched_sizes,
            )
        else:
            model = Swinv2Model(config)

        return model

    @staticmethod
    def _infer_all_stage_channels(config: Swinv2Config) -> List[int]:
        """Infer SwinV2 stage channels from HuggingFace config."""
        if hasattr(config, 'hidden_sizes') and config.hidden_sizes is not None:
            hidden_sizes = list(config.hidden_sizes)

            # Some configs may contain exactly one value for each stage.
            if hasattr(config, 'depths') and len(hidden_sizes) == len(config.depths):
                return hidden_sizes

            # Some configs may contain embedding output + stage outputs.
            if hasattr(config, 'depths') and len(hidden_sizes) == len(config.depths) + 1:
                return hidden_sizes[1:]

        if not hasattr(config, 'embed_dim'):
            raise AttributeError(
                'Cannot infer SwinV2 stage channels because config has no '
                '`embed_dim` attribute.'
            )

        if not hasattr(config, 'depths'):
            raise AttributeError(
                'Cannot infer SwinV2 stage channels because config has no '
                '`depths` attribute.'
            )

        embed_dim = int(config.embed_dim)
        num_stages = len(config.depths)

        return [embed_dim * (2 ** i) for i in range(num_stages)]

    def _get_stage_features_from_outputs(
        self,
        outputs,
        batch_size: int,
        height: int,
        width: int,
    ) -> List[torch.Tensor]:
        """Extract stage features from HuggingFace SwinV2 outputs.

        Preferred source:
            outputs.reshaped_hidden_states

        Fallback source:
            outputs.hidden_states
        """
        reshaped_hidden_states = getattr(outputs, 'reshaped_hidden_states', None)

        if reshaped_hidden_states is not None:
            feats = list(reshaped_hidden_states)

            # HuggingFace usually returns:
            #   embedding output + 4 stage outputs
            if len(feats) == len(self.all_stage_channels) + 1:
                feats = feats[1:]

            if len(feats) < max(self.out_indices) + 1:
                raise RuntimeError(
                    f'Not enough reshaped hidden states. '
                    f'Got {len(feats)}, but out_indices={self.out_indices}.'
                )

            return feats

        hidden_states = getattr(outputs, 'hidden_states', None)

        if hidden_states is None:
            raise RuntimeError(
                'SwinV2 outputs do not contain `reshaped_hidden_states` or '
                '`hidden_states`. Please make sure output_hidden_states=True.'
            )

        hidden_states = list(hidden_states)

        # HuggingFace usually returns:
        #   embedding output + 4 stage outputs
        if len(hidden_states) == len(self.all_stage_channels) + 1:
            hidden_states = hidden_states[1:]

        feats = []

        for x in hidden_states:
            # x: [B, L, C]
            if x.ndim != 3:
                raise RuntimeError(
                    f'Expected hidden state to have shape [B, L, C], '
                    f'but got {tuple(x.shape)}.'
                )

            b, l, c = x.shape

            spatial_size = int(math.sqrt(l))
            if spatial_size * spatial_size != l:
                raise RuntimeError(
                    f'Cannot reshape hidden state with sequence length {l} '
                    f'to square feature map.'
                )

            feat = x.transpose(1, 2).contiguous()
            feat = feat.view(b, c, spatial_size, spatial_size)
            feats.append(feat)

        if len(feats) < max(self.out_indices) + 1:
            raise RuntimeError(
                f'Not enough hidden states. '
                f'Got {len(feats)}, but out_indices={self.out_indices}.'
            )

        return feats

    def _ensure_nchw(
        self,
        feat: torch.Tensor,
        expected_channels: int,
    ) -> torch.Tensor:
        """Ensure feature tensor is channel-first NCHW."""
        if feat.ndim != 4:
            raise RuntimeError(
                f'Expected 4D feature map, but got shape {tuple(feat.shape)}.'
            )

        # Already NCHW.
        if feat.shape[1] == expected_channels:
            return feat

        # Maybe NHWC.
        if feat.shape[-1] == expected_channels:
            return feat.permute(0, 3, 1, 2).contiguous()

        raise RuntimeError(
            f'Cannot identify channel dimension. '
            f'Expected channels={expected_channels}, '
            f'but got feature shape={tuple(feat.shape)}.'
        )

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, ...]:
        """Forward.

        Args:
            x: Tensor with shape [B, T, C, H, W].

        Returns:
            Tuple of fused multi-scale features.
        """
        if x.ndim != 5:
            raise ValueError(
                f'HFSwinV2TemporalBackbone expects input shape '
                f'[B, T, C, H, W], but got {tuple(x.shape)}.'
            )

        b, t, c, h, w = x.shape

        if c != self.in_channels:
            raise ValueError(
                f'Input channel mismatch. '
                f'Expected {self.in_channels}, but got {c}.'
            )

        x = x.reshape(b * t, c, h, w).contiguous()

        outputs = self.swinv2(
            pixel_values=x,
            output_hidden_states=True,
            return_dict=True,
        )

        stage_feats = self._get_stage_features_from_outputs(
            outputs=outputs,
            batch_size=b * t,
            height=h,
            width=w,
        )

        fused_feats = []

        for fusion_idx, stage_idx in enumerate(self.out_indices):
            expected_channels = self.stage_channels[fusion_idx]

            feat = stage_feats[stage_idx]
            feat = self._ensure_nchw(
                feat=feat,
                expected_channels=expected_channels,
            )

            _, ch, fh, fw = feat.shape

            feat = feat.view(b, t, ch, fh, fw).contiguous()
            feat = self.temporal_fusions[fusion_idx](feat)

            fused_feats.append(feat)

        return tuple(fused_feats)

    def set_spatial_trainable(self, trainable: bool = True) -> None:
        """Set whether HuggingFace SwinV2 spatial encoder is trainable.

        This is the method name expected by some freeze hooks.
        """
        trainable = bool(trainable)
        self._spatial_frozen = not trainable

        for param in self.swinv2.parameters():
            param.requires_grad = trainable

        if trainable:
            self.swinv2.train(self.training)
        else:
            self.swinv2.eval()

    def set_spatial_encoder_trainable(self, trainable: bool = True) -> None:
        """Alias for compatibility with FreezeBackboneByEpochHook."""
        self.set_spatial_trainable(trainable)

    def freeze_spatial_encoder(self) -> None:
        """Freeze HuggingFace SwinV2 spatial encoder."""
        self.set_spatial_trainable(False)

    def unfreeze_spatial_encoder(self) -> None:
        """Unfreeze HuggingFace SwinV2 spatial encoder."""
        self.set_spatial_trainable(True)

    def train(self, mode: bool = True):
        """Override train to keep frozen spatial encoder in eval mode."""
        super().train(mode)

        if self._spatial_frozen:
            self.swinv2.eval()
            for param in self.swinv2.parameters():
                param.requires_grad = False

        if self.norm_eval:
            for module in self.modules():
                if isinstance(module, (nn.BatchNorm2d, nn.SyncBatchNorm)):
                    module.eval()

        return self


# Backward-compatible Python alias.
SwinV2TemporalBackbone = HFSwinV2TemporalBackbone

# Backward-compatible registry alias.
# This allows configs using type='SwinV2TemporalBackbone' to work too.
try:
    MODELS.register_module(
        name='SwinV2TemporalBackbone',
        module=HFSwinV2TemporalBackbone,
        force=True,
    )
except TypeError:
    MODELS.register_module(
        name='SwinV2TemporalBackbone',
        force=True,
    )(HFSwinV2TemporalBackbone)
