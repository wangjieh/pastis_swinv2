# pastis_mmseg/models/backbones/hf_swinv2_temporal.py

from typing import List, Optional, Sequence, Tuple
import math

import torch
import torch.nn as nn
from mmengine.model import BaseModule
from mmseg.registry import MODELS

try:
    from transformers import Swinv2Config, Swinv2Model
except ImportError as exc:
    raise ImportError(
        'This project requires HuggingFace transformers. '
        'Please install it with: pip install transformers'
    ) from exc


class TemporalMeanFusion(nn.Module):
    """Mean pooling over temporal dimension.

    Args:
        x: Tensor with shape [B, T, C, H, W].

    Returns:
        Tensor with shape [B, C, H, W].
    """

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim != 5:
            raise ValueError(
                f'TemporalMeanFusion expects [B, T, C, H, W], '
                f'but got {tuple(x.shape)}.'
            )
        return x.mean(dim=1)


class TemporalMaxFusion(nn.Module):
    """Max pooling over temporal dimension.

    Args:
        x: Tensor with shape [B, T, C, H, W].

    Returns:
        Tensor with shape [B, C, H, W].
    """

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim != 5:
            raise ValueError(
                f'TemporalMaxFusion expects [B, T, C, H, W], '
                f'but got {tuple(x.shape)}.'
            )
        return x.max(dim=1).values


class TemporalAttentionFusion(nn.Module):
    """Stage-specific temporal attention fusion.

    The ``dim`` argument must match the real channel number of the current
    SwinV2 stage.

    Common stage channels:
        SwinV2-Tiny / Small: [96, 192, 384, 768]
        SwinV2-Base:         [128, 256, 512, 1024]
        SwinV2-Large:        [192, 384, 768, 1536]
    """

    def __init__(
        self,
        dim: int,
        reduction: int = 4,
        min_hidden_dim: int = 16,
    ) -> None:
        super().__init__()
        hidden_dim = max(dim // reduction, min_hidden_dim)

        self.norm = nn.LayerNorm(dim)
        self.attn = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward.

        Args:
            x: Tensor with shape [B, T, C, H, W].

        Returns:
            Tensor with shape [B, C, H, W].
        """
        if x.ndim != 5:
            raise ValueError(
                f'TemporalAttentionFusion expects [B, T, C, H, W], '
                f'but got {tuple(x.shape)}.'
            )

        b, t, c, h, w = x.shape

        pooled = x.mean(dim=(-2, -1))       # [B, T, C]
        pooled = self.norm(pooled)          # [B, T, C]

        weight = self.attn(pooled)          # [B, T, 1]
        weight = torch.softmax(weight, dim=1)
        weight = weight.view(b, t, 1, 1, 1)

        return (x * weight).sum(dim=1)      # [B, C, H, W]


def _make_temporal_fusion(
    fusion_type: str,
    dim: int,
    reduction: int = 4,
) -> nn.Module:
    fusion_type = fusion_type.lower()

    if fusion_type in ('attention', 'attn', 'temporal_attention'):
        return TemporalAttentionFusion(dim=dim, reduction=reduction)

    if fusion_type in ('mean', 'avg', 'average'):
        return TemporalMeanFusion()

    if fusion_type in ('max', 'maximum'):
        return TemporalMaxFusion()

    raise ValueError(
        f'Unsupported temporal_fusion={fusion_type}. '
        f'Available options: attention, mean, max.'
    )


@MODELS.register_module()
class HFSwinV2TemporalBackbone(BaseModule):
    """HuggingFace SwinV2 spatial encoder + multi-scale temporal fusion.

    Expected input:
        [B, T, C, H, W]

    For the current PASTIS setting:
        [B, 12, 13, 128, 128]

    Output:
        A tuple of multi-scale features for MMSeg decode heads.

    For SwinV2-Base, the returned feature channels should be:
        [128, 256, 512, 1024]

    Important implementation detail:
        Different HuggingFace transformers versions may return
        ``reshaped_hidden_states`` with slightly different offsets. Some
        versions include the patch-embedding feature as the first element,
        while others return only stage outputs. Therefore this backbone does
        NOT assume fixed hidden-state indices. It collects all candidate
        feature maps and selects the required stage feature by channel number.
        This fixes errors such as:

            Cannot identify channel dimension.
            Expected channels=128, but got feature shape=(12, 256, 16, 16)
    """

    size_to_default_cfg = {
        'tiny': dict(
            embed_dim=96,
            depths=[2, 2, 6, 2],
            num_heads=[3, 6, 12, 24],
        ),
        'small': dict(
            embed_dim=96,
            depths=[2, 2, 18, 2],
            num_heads=[3, 6, 12, 24],
        ),
        'base': dict(
            embed_dim=128,
            depths=[2, 2, 18, 2],
            num_heads=[4, 8, 16, 32],
        ),
        'large': dict(
            embed_dim=192,
            depths=[2, 2, 18, 2],
            num_heads=[6, 12, 24, 48],
        ),
    }

    def __init__(
        self,
        hf_model_name_or_path: Optional[str] = None,
        swinv2_size: str = 'base',
        pretrained: bool = True,
        in_channels: int = 13,
        image_size: int = 128,
        patch_size: int = 4,
        window_size: int = 8,
        out_indices: Sequence[int] = (0, 1, 2, 3),
        temporal_fusion: str = 'attention',
        temporal_reduction: int = 4,
        output_hidden_states: bool = True,
        gradient_checkpointing: bool = False,
        norm_eval: bool = False,
        init_cfg: Optional[dict] = None,
        **kwargs,
    ) -> None:
        super().__init__(init_cfg=init_cfg)

        self.hf_model_name_or_path = hf_model_name_or_path
        self.swinv2_size = swinv2_size.lower()
        self.pretrained = pretrained
        self.in_channels = int(in_channels)
        self.image_size = int(image_size)
        self.patch_size = int(patch_size)
        self.window_size = int(window_size)
        self.out_indices = tuple(int(i) for i in out_indices)
        self.temporal_fusion = temporal_fusion
        self.temporal_reduction = int(temporal_reduction)
        self.output_hidden_states = output_hidden_states
        self.gradient_checkpointing = gradient_checkpointing
        self.norm_eval = norm_eval

        self._spatial_frozen = False

        self.config = self._build_config(
            hf_model_name_or_path=hf_model_name_or_path,
            swinv2_size=self.swinv2_size,
            in_channels=self.in_channels,
            image_size=self.image_size,
            patch_size=self.patch_size,
            window_size=self.window_size,
        )

        self.swinv2 = self._build_swinv2_model(
            config=self.config,
            hf_model_name_or_path=hf_model_name_or_path,
            pretrained=pretrained,
        )

        if self.gradient_checkpointing:
            if hasattr(self.swinv2, 'gradient_checkpointing_enable'):
                self.swinv2.gradient_checkpointing_enable()
            else:
                raise RuntimeError(
                    'The current transformers Swinv2Model does not support '
                    'gradient_checkpointing_enable().'
                )

        self.all_stage_channels = self._infer_all_stage_channels(self.config)

        if max(self.out_indices) >= len(self.all_stage_channels):
            raise ValueError(
                f'out_indices={self.out_indices} is incompatible with '
                f'all_stage_channels={self.all_stage_channels}.'
            )

        self.stage_channels = [
            self.all_stage_channels[i] for i in self.out_indices
        ]

        self.temporal_fusions = nn.ModuleList([
            _make_temporal_fusion(
                fusion_type=temporal_fusion,
                dim=channels,
                reduction=self.temporal_reduction,
            )
            for channels in self.stage_channels
        ])

        # MMSeg decode heads can read this if needed.
        self.out_channels = self.stage_channels

    def _build_config(
        self,
        hf_model_name_or_path: Optional[str],
        swinv2_size: str,
        in_channels: int,
        image_size: int,
        patch_size: int,
        window_size: int,
    ) -> Swinv2Config:
        """Build HuggingFace SwinV2 config."""
        if hf_model_name_or_path:
            config = Swinv2Config.from_pretrained(hf_model_name_or_path)
        else:
            if swinv2_size not in self.size_to_default_cfg:
                raise ValueError(
                    f'Unsupported swinv2_size={swinv2_size}. '
                    f'Available: {list(self.size_to_default_cfg.keys())}'
                )

            default_cfg = self.size_to_default_cfg[swinv2_size]
            config = Swinv2Config(
                image_size=image_size,
                patch_size=patch_size,
                num_channels=in_channels,
                embed_dim=default_cfg['embed_dim'],
                depths=default_cfg['depths'],
                num_heads=default_cfg['num_heads'],
                window_size=window_size,
            )

        # Force these values to match the current PASTIS data and project.
        config.num_channels = in_channels
        config.image_size = image_size
        config.patch_size = patch_size

        if hasattr(config, 'window_size'):
            config.window_size = window_size

        config.output_hidden_states = True
        config.return_dict = True

        return config

    def _build_swinv2_model(
        self,
        config: Swinv2Config,
        hf_model_name_or_path: Optional[str],
        pretrained: bool,
    ) -> Swinv2Model:
        """Build HuggingFace SwinV2 model.

        When pretrained=True, ``ignore_mismatched_sizes=True`` allows loading
        3-channel ImageNet checkpoints into this 13-channel PASTIS model. The
        mismatched patch embedding will be re-initialized by transformers.
        """
        if pretrained:
            if not hf_model_name_or_path:
                raise ValueError(
                    'pretrained=True requires hf_model_name_or_path to be set.'
                )

            return Swinv2Model.from_pretrained(
                hf_model_name_or_path,
                config=config,
                ignore_mismatched_sizes=True,
            )

        return Swinv2Model(config)

    @staticmethod
    def _infer_all_stage_channels(config: Swinv2Config) -> List[int]:
        """Infer SwinV2 stage channels from HuggingFace config."""
        if hasattr(config, 'hidden_sizes') and config.hidden_sizes is not None:
            hidden_sizes = list(config.hidden_sizes)
            if hasattr(config, 'depths') and len(hidden_sizes) == len(config.depths):
                return [int(v) for v in hidden_sizes]

        if not hasattr(config, 'embed_dim'):
            raise AttributeError(
                'Cannot infer SwinV2 stage channels because config has no '
                '`embed_dim` attribute.'
            )

        if not hasattr(config, 'depths'):
            raise AttributeError(
                'Cannot infer SwinV2 stage channels because config has no '
                '`depths` attribute.'
            )

        embed_dim = int(config.embed_dim)
        num_stages = len(config.depths)

        return [embed_dim * (2 ** i) for i in range(num_stages)]

    @staticmethod
    def _is_square_number(value: int) -> bool:
        root = int(math.sqrt(value))
        return root * root == value

    def _to_nchw_candidates(
        self,
        tensor: torch.Tensor,
        source: str,
        index: int,
    ) -> List[Tuple[torch.Tensor, str]]:
        """Convert one hidden-state tensor into possible NCHW feature maps.

        Returns:
            A list of ``(feature, description)`` pairs.
        """
        candidates = []

        if tensor.ndim == 4:
            # Case 1: already NCHW.
            if tensor.shape[1] in self.all_stage_channels:
                candidates.append((
                    tensor.contiguous(),
                    f'{source}[{index}] as NCHW shape={tuple(tensor.shape)}',
                ))

            # Case 2: NHWC.
            if tensor.shape[-1] in self.all_stage_channels:
                feat = tensor.permute(0, 3, 1, 2).contiguous()
                candidates.append((
                    feat,
                    f'{source}[{index}] as NHWC->NCHW shape={tuple(tensor.shape)}',
                ))

            return candidates

        if tensor.ndim == 3:
            # Case 3: sequence format [B, L, C].
            b, l, c = tensor.shape
            if c in self.all_stage_channels and self._is_square_number(l):
                spatial_size = int(math.sqrt(l))
                feat = tensor.transpose(1, 2).contiguous()
                feat = feat.view(b, c, spatial_size, spatial_size)
                candidates.append((
                    feat,
                    f'{source}[{index}] as BLC->NCHW shape={tuple(tensor.shape)}',
                ))

            # Case 4: sequence format [B, C, L].
            b, c, l = tensor.shape
            if c in self.all_stage_channels and self._is_square_number(l):
                spatial_size = int(math.sqrt(l))
                feat = tensor.contiguous().view(b, c, spatial_size, spatial_size)
                candidates.append((
                    feat,
                    f'{source}[{index}] as BCL->NCHW shape={tuple(tensor.shape)}',
                ))

            return candidates

        return candidates

    def _collect_candidate_features(self, outputs) -> List[Tuple[torch.Tensor, str]]:
        """Collect all candidate feature maps from SwinV2 outputs.

        We intentionally do not drop the first item of hidden states. For some
        HuggingFace SwinV2 versions, the first reshaped hidden state is exactly
        the 128-channel patch/stage-0 feature needed by UPerHead.
        """
        candidates: List[Tuple[torch.Tensor, str]] = []

        reshaped_hidden_states = getattr(outputs, 'reshaped_hidden_states', None)
        if reshaped_hidden_states is not None:
            for i, tensor in enumerate(list(reshaped_hidden_states)):
                candidates.extend(
                    self._to_nchw_candidates(
                        tensor=tensor,
                        source='reshaped_hidden_states',
                        index=i,
                    )
                )

        hidden_states = getattr(outputs, 'hidden_states', None)
        if hidden_states is not None:
            for i, tensor in enumerate(list(hidden_states)):
                candidates.extend(
                    self._to_nchw_candidates(
                        tensor=tensor,
                        source='hidden_states',
                        index=i,
                    )
                )

        if not candidates:
            raise RuntimeError(
                'SwinV2 outputs do not contain usable feature maps. '
                'Please make sure output_hidden_states=True.'
            )

        return candidates

    def _select_feature_by_channels(
        self,
        candidates: List[Tuple[torch.Tensor, str]],
        expected_channels: int,
        used_candidate_ids: set,
    ) -> Tuple[torch.Tensor, str]:
        """Select one feature map by channel number.

        Args:
            candidates: List of NCHW candidate features.
            expected_channels: Required channel number for the current stage.
            used_candidate_ids: Candidate object ids already used by earlier
                stages.

        Returns:
            Selected ``(feature, description)`` pair.
        """
        matched = []
        for feat, desc in candidates:
            if id(feat) in used_candidate_ids:
                continue
            if feat.ndim == 4 and feat.shape[1] == expected_channels:
                matched.append((feat, desc))

        if matched:
            # Prefer the largest spatial map if duplicates exist. For the same
            # channel number, this is the safest feature for dense prediction.
            matched.sort(key=lambda item: item[0].shape[-2] * item[0].shape[-1],
                         reverse=True)
            feat, desc = matched[0]
            used_candidate_ids.add(id(feat))
            return feat, desc

        available = [
            f'{desc}, nchw={tuple(feat.shape)}'
            for feat, desc in candidates
            if feat.ndim == 4
        ]

        raise RuntimeError(
            f'Cannot find a SwinV2 feature map with channels={expected_channels}. '
            f'Available candidates: {available}. '
            f'Expected stage channels are {self.stage_channels}.'
        )

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, ...]:
        """Forward.

        Args:
            x: Tensor with shape [B, T, C, H, W].

        Returns:
            Tuple of fused multi-scale features.
        """
        if x.ndim != 5:
            raise ValueError(
                f'HFSwinV2TemporalBackbone expects input shape '
                f'[B, T, C, H, W], but got {tuple(x.shape)}.'
            )

        b, t, c, h, w = x.shape

        if c != self.in_channels:
            raise ValueError(
                f'Input channel mismatch. '
                f'Expected {self.in_channels}, but got {c}.'
            )

        x = x.reshape(b * t, c, h, w).contiguous()

        outputs = self.swinv2(
            pixel_values=x,
            output_hidden_states=True,
            return_dict=True,
        )

        candidates = self._collect_candidate_features(outputs)

        fused_feats = []
        used_candidate_ids = set()

        for fusion_idx, expected_channels in enumerate(self.stage_channels):
            feat, _ = self._select_feature_by_channels(
                candidates=candidates,
                expected_channels=expected_channels,
                used_candidate_ids=used_candidate_ids,
            )

            _, ch, fh, fw = feat.shape
            feat = feat.view(b, t, ch, fh, fw).contiguous()
            feat = self.temporal_fusions[fusion_idx](feat)

            fused_feats.append(feat)

        return tuple(fused_feats)

    def set_spatial_trainable(self, trainable: bool) -> None:
        """Set whether the HuggingFace SwinV2 spatial encoder is trainable.

        This method is kept for compatibility with older freeze hooks.
        """
        trainable = bool(trainable)
        self._spatial_frozen = not trainable

        for param in self.swinv2.parameters():
            param.requires_grad = trainable

        if trainable:
            self.swinv2.train()
        else:
            self.swinv2.eval()

    def set_spatial_encoder_trainable(self, trainable: bool) -> None:
        """Alias used by the current freeze hook."""
        self.set_spatial_trainable(trainable)

    def freeze_spatial_encoder(self) -> None:
        """Freeze HuggingFace SwinV2 spatial encoder."""
        self.set_spatial_trainable(False)

    def unfreeze_spatial_encoder(self) -> None:
        """Unfreeze HuggingFace SwinV2 spatial encoder."""
        self.set_spatial_trainable(True)

    def train(self, mode: bool = True):
        """Override train to keep frozen spatial encoder in eval mode."""
        super().train(mode)

        if self._spatial_frozen:
            self.swinv2.eval()
            for param in self.swinv2.parameters():
                param.requires_grad = False

        if self.norm_eval:
            for module in self.modules():
                if isinstance(module, (nn.BatchNorm2d, nn.SyncBatchNorm)):
                    module.eval()

        return self


# Backward-compatible registry alias.
# Some previous configs may use type='SwinV2TemporalBackbone'.
SwinV2TemporalBackbone = HFSwinV2TemporalBackbone

try:
    MODELS.register_module(
        name='SwinV2TemporalBackbone',
        module=HFSwinV2TemporalBackbone,
        force=True,
    )
except TypeError:
    # Older registry implementations may not accept force=True.
    try:
        MODELS.register_module(
            name='SwinV2TemporalBackbone',
            module=HFSwinV2TemporalBackbone,
        )
    except KeyError:
        pass
