import argparse

from mmengine.config import Config, DictAction
from mmengine.runner import Runner
from mmseg.utils import register_all_modules

import pastis_mmseg  # noqa: F401


def parse_args():
    parser = argparse.ArgumentParser(description='Train PASTIS SwinV2 MMSeg model')
    parser.add_argument('config', help='Path to config file')
    parser.add_argument('--work-dir', help='Working directory')
    parser.add_argument('--resume', action='store_true', help='Resume from latest checkpoint')
    parser.add_argument(
        '--launcher',
        choices=['none', 'pytorch', 'slurm', 'mpi'],
        default='none',
        help='Job launcher')
    parser.add_argument(
        '--cfg-options',
        nargs='+',
        action=DictAction,
        help='Override config options, e.g. --cfg-options train_dataloader.batch_size=2')
    return parser.parse_args()


def main():
    args = parse_args()
    register_all_modules(init_default_scope=True)

    cfg = Config.fromfile(args.config)
    cfg.launcher = args.launcher

    if args.work_dir is not None:
        cfg.work_dir = args.work_dir
    if args.resume:
        cfg.resume = True
    if args.cfg_options is not None:
        cfg.merge_from_dict(args.cfg_options)

    runner = Runner.from_cfg(cfg)
    runner.train()


if __name__ == '__main__':
    main()
