import argparse
import json
from pathlib import Path

import torch
from tqdm import tqdm


def parse_args():
    parser = argparse.ArgumentParser(description='Compute PASTIS channel mean/std')
    parser.add_argument('--s2-dir', required=True, help='Path to pastis_r_train/s2_images')
    parser.add_argument('--out', default='pastis_train_mean_std.json')
    return parser.parse_args()


def numeric_key(path: Path):
    try:
        return int(path.stem)
    except ValueError:
        return path.stem


def load_tensor(path: Path):
    obj = torch.load(str(path), map_location='cpu')
    if isinstance(obj, dict):
        for key in ('image', 'img', 's2', 's2_image', 'data', 'x'):
            if key in obj:
                obj = obj[key]
                break
    if not torch.is_tensor(obj):
        obj = torch.as_tensor(obj)
    if obj.ndim != 4:
        raise ValueError(f'{path} must be [T, C, H, W], got {tuple(obj.shape)}')
    return obj.float()


def main():
    args = parse_args()
    s2_dir = Path(args.s2_dir)
    files = sorted([p for p in s2_dir.iterdir() if p.suffix == '.pt'], key=numeric_key)
    if len(files) == 0:
        raise RuntimeError(f'No .pt files found in {s2_dir}')

    channel_sum = None
    channel_sq_sum = None
    count = 0

    for path in tqdm(files):
        x = load_tensor(path)  # [T, C, H, W]
        t, c, h, w = x.shape
        flat_count = t * h * w

        s = x.sum(dim=(0, 2, 3), dtype=torch.float64)
        ss = (x.double() ** 2).sum(dim=(0, 2, 3))

        if channel_sum is None:
            channel_sum = torch.zeros(c, dtype=torch.float64)
            channel_sq_sum = torch.zeros(c, dtype=torch.float64)

        channel_sum += s
        channel_sq_sum += ss
        count += flat_count

    mean = channel_sum / count
    var = channel_sq_sum / count - mean ** 2
    std = torch.sqrt(torch.clamp(var, min=1e-12))

    result = {
        'num_files': len(files),
        'count_per_channel': int(count),
        'mean': [float(v) for v in mean],
        'std': [float(v) for v in std],
    }

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result, indent=2), encoding='utf-8')

    print(json.dumps(result, indent=2))
    print(f'Saved to {out_path}')


if __name__ == '__main__':
    main()
