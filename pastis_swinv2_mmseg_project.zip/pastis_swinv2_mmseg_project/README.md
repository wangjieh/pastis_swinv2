# PASTIS SwinV2 Temporal Segmentation for MMSegmentation 1.2.2

这个工程用于你当前的 PASTIS `.pt` 数据格式：

```text
pastis_dataset/
├── pastis_r_train/
│   ├── s2_images/
│   │   ├── 0.pt          # [12, 13, 128, 128]
│   │   ├── 1.pt
│   │   └── ...
│   └── targets.pt        # [N, 128, 128], label 0-18 valid, -1 ignore
├── pastis_r_val/
│   ├── s2_images/
│   └── targets.pt
└── pastis_r_test/
    ├── s2_images/
    └── targets.pt
```

核心结构：

```text
[B, 12, 13, 128, 128]
→ HuggingFace SwinV2 spatial encoder, per timestamp
→ multi-scale temporal attention fusion
→ Linear Probe / UPerNet decode head
→ [B, 19, 128, 128]
```

默认规则：

```text
num_classes = 19
ignore_index = -1
input shape = [B, 12, 13, 128, 128]
train epochs = 50
freeze SwinV2 spatial encoder for first 10 epochs = first 20%
```

---

## 1. 环境

你已经给定：

```text
mmcv = 2.1.1
mmpretrain = 1.2.0
mmsegmentation = 1.2.2
```

本工程额外需要 HuggingFace Transformers：

```bash
pip install transformers safetensors pillow tqdm
```

然后在工程根目录安装：

```bash
pip install -e .
```

---

## 2. 本地 SwinV2 权重

你可以本地下载 HuggingFace 风格的 SwinV2 目录，例如：

```text
pretrained/
└── swinv2-base-patch4-window8-256/
    ├── config.json
    ├── model.safetensors 或 pytorch_model.bin
    └── ...
```

本工程默认使用环境变量指定：

```bash
export SWINV2_PATH=/absolute/path/to/swinv2-base-patch4-window8-256
export SWINV2_SIZE=base
export PASTIS_DATA_ROOT=/absolute/path/to/pastis_dataset
```

默认尺寸映射：

| SWINV2_SIZE | embed_dims | stage channels |
|---|---:|---|
| tiny | 96 | [96, 192, 384, 768] |
| small | 96 | [96, 192, 384, 768] |
| base | 128 | [128, 256, 512, 1024] |
| large | 192 | [192, 384, 768, 1536] |

如果你使用自定义 SwinV2 配置，可以手动覆盖：

```bash
export SWINV2_EMBED_DIMS=128
```

注意：因为你的输入是 13 通道，而大多数 HF SwinV2 预训练权重是 3 通道，代码会用 `ignore_mismatched_sizes=True` 加载权重，第一层 patch embedding 会重新初始化，其余能匹配的权重会加载。

---

## 3. 训练

### Linear Probe

```bash
export PASTIS_DATA_ROOT=/absolute/path/to/pastis_dataset
export SWINV2_PATH=/absolute/path/to/swinv2-base-patch4-window8-256
export SWINV2_SIZE=base

python tools/train.py configs/pastis_swinv2_base_linear_probe_50e.py \
  --work-dir work_dirs/pastis_swinv2_base_linear_probe
```

### UPerNet

```bash
export PASTIS_DATA_ROOT=/absolute/path/to/pastis_dataset
export SWINV2_PATH=/absolute/path/to/swinv2-base-patch4-window8-256
export SWINV2_SIZE=base

python tools/train.py configs/pastis_swinv2_base_upernet_50e.py \
  --work-dir work_dirs/pastis_swinv2_base_upernet
```

多卡训练示例：

```bash
bash -c 'export PASTIS_DATA_ROOT=/absolute/path/to/pastis_dataset; \
export SWINV2_PATH=/absolute/path/to/swinv2-base-patch4-window8-256; \
export SWINV2_SIZE=base; \
torchrun --nproc_per_node=4 tools/train.py configs/pastis_swinv2_base_upernet_50e.py \
--launcher pytorch --work-dir work_dirs/pastis_swinv2_base_upernet'
```

---

## 4. 测试

```bash
python tools/test.py configs/pastis_swinv2_base_upernet_50e.py \
  work_dirs/pastis_swinv2_base_upernet/best_mIoU_iter_xxx.pth
```

或者：

```bash
python tools/test.py configs/pastis_swinv2_base_linear_probe_50e.py \
  work_dirs/pastis_swinv2_base_linear_probe/best_mIoU_iter_xxx.pth
```

---

## 5. 单文件 / 文件夹推理

单个 `.pt` 文件：

```bash
python tools/infer.py \
  configs/pastis_swinv2_base_upernet_50e.py \
  work_dirs/pastis_swinv2_base_upernet/best_mIoU_iter_xxx.pth \
  /absolute/path/to/pastis_dataset/pastis_r_test/s2_images/0.pt \
  --out-dir outputs/infer_upernet \
  --device cuda:0
```

整个 `s2_images` 文件夹：

```bash
python tools/infer.py \
  configs/pastis_swinv2_base_upernet_50e.py \
  work_dirs/pastis_swinv2_base_upernet/best_mIoU_iter_xxx.pth \
  /absolute/path/to/pastis_dataset/pastis_r_test/s2_images \
  --out-dir outputs/infer_upernet \
  --device cuda:0
```

输出包括：

```text
xxx_pred.pt
xxx_pred.png
```

---

## 6. 计算 13 通道 mean/std

如果官方预处理后的 `.pt` 还没有做标准化，建议先计算训练集统计量：

```bash
python tools/compute_mean_std.py \
  --s2-dir /absolute/path/to/pastis_dataset/pastis_r_train/s2_images \
  --out outputs/pastis_train_mean_std.json
```

然后把 JSON 里的 `mean` / `std` 填到两个 config 的：

```python
data_preprocessor = dict(
    type='PastisSegDataPreProcessor',
    mean=[...13 values...],
    std=[...13 values...],
    seg_pad_val=-1)
```

如果你的 `.pt` 已经做过标准化，可以保持默认：

```python
mean=[0.0] * 13
std=[1.0] * 13
```

---

## 7. 切换 tiny / small / large

不需要改代码，只要换环境变量和本地权重路径。

### tiny

```bash
export SWINV2_SIZE=tiny
export SWINV2_PATH=/absolute/path/to/swinv2-tiny-local-dir
```

### small

```bash
export SWINV2_SIZE=small
export SWINV2_PATH=/absolute/path/to/swinv2-small-local-dir
```

### large

```bash
export SWINV2_SIZE=large
export SWINV2_PATH=/absolute/path/to/swinv2-large-local-dir
```

如果 HuggingFace config 里的 embed dim 不符合上表，额外设置：

```bash
export SWINV2_EMBED_DIMS=你的embed维度
```

---

## 8. 重要实现说明

1. `.pt` 图像按数字文件名排序，但标签索引使用文件名 stem，例如 `17.pt` 对应 `targets[17]`。
2. 输入张量必须是 `[12, 13, 128, 128]`。
3. 标签必须是 `[128, 128]`，有效值 `0-18`，ignore 值 `-1`。
4. `num_classes=19`，不要把 `-1` 当成类别。
5. 默认只冻结 HuggingFace SwinV2 空间编码器前 10 轮，temporal fusion 和 decode head 继续训练。
6. 如果你想前 10 轮冻结整个 custom backbone，把 config 里的 hook 改成：

```python
custom_hooks = [
    dict(type='FreezeBackboneByEpochHook', freeze_epochs=10, target='backbone')
]
```

---

## 9. 常见问题

### Q1: 报错 `No module named transformers`

安装：

```bash
pip install transformers safetensors
```

### Q2: 报错第一层权重 shape 不匹配

这是 3 通道预训练权重加载到 13 通道输入导致的。配置里已经设置：

```python
ignore_mismatched_sizes=True
```

这属于预期行为，第一层会重新初始化。

### Q3: CUDA 显存不够

SwinV2 base 会把 batch 展开为 `B * 12` 张图送进 SwinV2，显存压力较大。优先尝试：

```python
batch_size = 1
gradient_checkpointing = True
```

或者切换 tiny / small。

### Q4: mIoU 异常低

优先检查：

```bash
python - <<'PY'
import torch
y = torch.load('/absolute/path/to/pastis_dataset/pastis_r_train/targets.pt')
print(y.shape, y.dtype, torch.unique(y)[:30], torch.unique(y)[-30:])
PY
```

应包含 `-1` 和 `0-18`，不能把 `-1` 存成 `255`。
